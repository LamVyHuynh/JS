// Ưu tiên ()
let diemToan = 9.5;
let diemVan = 8.75;

let dtb = (diemToan + diemVan) / 2;
console.log(dtb);

// right to left
let x = (y = 25);
// left to right
let c = 25 - 7 + 8 - 1;
