// 7.2 -  Các phép toán cơ bản
let a = 7;
let b = 2;

let tong = a + b;
let hieu = a - b;
let tich = a * b;
let thuong = a / b;
let soDu = a % b;

// xuất kết quả
console.log("Tổng 2 số: " + tong);
console.log("Hiệu 2 số: " + hieu);
console.log("Tích 2 số: " + tich);
console.log("Thương 2 số: " + thuong);
console.log("Số dư của phép chia a cho b là: " + soDu);
