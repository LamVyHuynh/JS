//016. bài 16.1, if else:
// xuất thông báo cho người dùng nhập điểm
let dtb = Number(prompt("Mời cụ nhập điểm:"));
// kiểm tra điều kiện
if (dtb >= 5.0) {
  console.log("Bạn đã đỗ");
} else {
  console.log("Bạn đã tạch");
}

