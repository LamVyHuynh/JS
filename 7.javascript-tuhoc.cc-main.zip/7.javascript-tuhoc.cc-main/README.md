Code và bài tập JS - Khóa học lập trình js tại <a href="http://js.tuhoc.cc" target="_blank">js.tuhoc.cc</a>  
Nhóm thảo luận dành cho thành viên: <a href="http://dc.tuhoc.cc" target="_blank">http://dc.tuhoc.cc</a>  
Hãy truy cập vào <a href="http://tuhoc.cc" target="_blank">http://tuhoc.cc</a> để học thêm nhiều ngôn ngữ lập trình phổ biến khác!  



                            _oo0oo_
                            o8888888o
                            88" . "88
                            (| -_- |)
                            0\  =  /0
                            ___/`---'\___
                        .' \\|     | '.
                        / \\|||  :  ||| \
                        / _||||| -:- |||||- \
                    |   | \\\  -  / |   |
                    | \_|  ''\---/''  |_/ |
                    \  .-\__  '-'  ___/-. /
                    ___'. .'  /--.--\  `. .'___
                ."" '<  `.___\_<|>_/___.' >' "".
                | | :  `- \`.;`\ _ /`;.`/ - ` : | |
                \  \ `_.   \_ __\ /__ _/   .-` /  /
            =====`-.____`.___ \_____/___.-`___.-'=====
                            `=---='

     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
       http://Tuhoc.cc Phật phù hộ, không bao giờ BUG
     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
