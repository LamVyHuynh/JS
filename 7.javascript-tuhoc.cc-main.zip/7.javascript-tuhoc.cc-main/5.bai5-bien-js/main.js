// hàm hiển thị hộp thoại lên trên trình duyệt cho người dùng
// alert("xin chao");
// hàm hiển thị hộp nhập liệu cho người dùng
/* 
dòng 1 
dòng 2
dòng 3

*/
// prompt("mời nhập vào tên của bạn:");
// khai báo biến
var myName;
let yourName;
// const doSoi;

// khởi tạo biến
var diemToan = 10;
const doSoi = 100;
let firstName = "Alice";
// xuất giá trị của biến
console.log(diemToan);
console.log("Điểm toán của bạn là: " + diemToan + " điểm");
console.log(doSoi);
console.log(firstName);

// thử thay đổi giá trị của biến
diemToan = 5;
console.log("Điểm toán của bạn là: " + diemToan + " điểm");
firstName = "Jacky";
console.log(firstName);

// thử gán lại biến hằng số
// doSoi = 50;
// console.log(doSoi);
