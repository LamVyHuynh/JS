//22. while true
// Tăng n lên cho đến khi n=10
let n = 0;
while (true) {
  n++;
  alert(n);
  if (n === 10) {
    break;
  }
}
