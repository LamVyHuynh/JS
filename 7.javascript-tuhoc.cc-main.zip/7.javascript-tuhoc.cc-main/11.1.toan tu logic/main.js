//11. toán tử logic
let i = 7;
// kiểm tra xem i >0 và i < 10 không?
console.log(i > 0 && i < 10); //true
// kiểm tra i<0 hoặc i<10 không?
console.log(i > 0 || i < 10); //true
// phủ định
console.log(!(i > 0 || i < 10)); //false
