// khai báo biến
// let userName;

// hiển thị hộp nhập liệu
let userName = prompt("Mời cụ nhập tên: ");
console.log(userName);
console.log("Tên của bạn là: " + userName);
console.log("Chào mừng " + userName + " đến với trang tuhoc.cc");
