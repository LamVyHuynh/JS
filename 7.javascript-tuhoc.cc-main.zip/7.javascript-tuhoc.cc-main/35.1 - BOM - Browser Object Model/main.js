//35.1 BOM - Browser Object Model
//1 số phương thức vốn đã quen thuộc:
window.alert("Xin chào!");
alert("Xin chào");
window.console.log("tuhoc.cc");
console.log("tuhoc.cc");

// Lấy chiều rộng của cửa sổ trình duyệt
window.innerWidth;
innerWidth;
// Lấy chiều cao của cửa sổ trình duyệt
window.innerHeight;
innerHeight;

//Theo dõi chuyển động chuột
window.onmousemove = function () {
  console.log("con chuột cụ đang di chuyển");
};
