//36.1 - Document Object Model Khái quát về DOM
// console.log(document);

// console.log(document.firstElementChild);

// console.log(document.firstElementChild.firstElementChild);
// console.log(document.firstElementChild.lastElementChild);
