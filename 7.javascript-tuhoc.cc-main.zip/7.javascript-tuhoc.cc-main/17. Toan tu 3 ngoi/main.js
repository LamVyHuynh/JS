//17. Toán tử 3 ngôi
let number = -10;
let message = number >= 0 ? "Số dương" : "Số âm";
console.log(message);
// Nếu sử dụng if else thông thường
if (number >= 0) {
  console.log("Số dương");
} else {
  console.log("Số âm");
}

let number2 = 10;
console.log(number2 % 2 === 0);
let message2 = number2 % 2 === 0 ? "Số chẵn" : "Số lẻ";
console.log(message2);
