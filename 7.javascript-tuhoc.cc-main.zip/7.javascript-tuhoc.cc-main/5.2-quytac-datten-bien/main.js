// tên biến hợp lệ ( bắt đầu chữ cái, _, $)
let name;
let Name;
let _name;
let $name;
// các trường hợp không hợp lệ
// let 1name;
// let @name;

// let var;
// let const;

//camelCase
let doSoi;
let doSoiCuaNuoc;
