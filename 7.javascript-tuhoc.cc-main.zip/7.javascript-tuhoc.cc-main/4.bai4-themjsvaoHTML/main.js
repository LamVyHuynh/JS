alert("xin chào, đây là 1 thông báo từ javascript");
alert("tôi mới học js");
alert("tại tuhoc.cc");
