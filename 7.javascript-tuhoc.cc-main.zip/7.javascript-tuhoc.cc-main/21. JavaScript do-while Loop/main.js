//21. JavaScript do-while Loop
let i = 7;
do {
  console.log(i);
  i++;
} while (i <= 5);

// ôn lại vòng while so sánh với do while
while (i <= 5) {
  console.log(i);
  i++;
}
