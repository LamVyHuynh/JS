alert("xin chào");
alert("tôi mới học js");
alert("tại tuhoc.cc");
console.log("đây là thông điệp trong cs log");
