//kiểu number
let soNguyen = 10;
let soThuc = 3.14;

// kiểu boolean
let check = false;

// kiểu undefined
let diemToan;

//kiểu null
let connect = null;

// xuất giá trị của biến
console.log(soNguyen);
console.log(soThuc);
console.log(typeof soNguyen);
console.log(typeof soThuc);

console.log(typeof check);
console.log(typeof diemToan);
console.log(typeof connect);

// xuất số nguyên an toàn tối đa/ tối thiểu
console.log("Số nguyên an toàn tối đa: " + Number.MAX_SAFE_INTEGER);
console.log("Số nguyên an toàn tối thiểu: ", Number.MIN_SAFE_INTEGER);
